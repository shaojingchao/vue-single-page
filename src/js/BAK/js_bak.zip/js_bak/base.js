define(function(){
    $.baseJs = {
        init: function() {
            var e = this;
            //e.tabStyle();       //选择版式
            e.examType();       //考试类型
            e.deleteLayer();    //删除选择题
        },

        //选择版式
        //tabStyle: function(){
        //    var tabli = $("#tabstyle li");
        //    var a4con = $(".box-a4");
        //    var a3con = $(".box-a3");
        //    tabli.on("click",function(){
        //        tabli.eq($(this).index()).children("span").addClass("choice")
        //            .parent().siblings().children("span").removeClass("choice");
        //        $(".tablayout").hide().eq($(this).index()).show();
        //    })
        //},
        //考试类型
        examType: function(){
            var tabtype = $("#examtype a");
            tabtype.on("click",function(){
                tabtype.eq($(this).index()).addClass("choice").siblings().removeClass("choice");
            });
            var $gaokao = $(".examtype-gk");   //高考仿真
            $qizhong = $(".examtype-qz");   //期中期末
            $danyuan = $(".examtype-dy");   //单元测试
            $keshi = $(".examtype-ks");   //课时训练
            // 高考仿真
            $("#examtype1").on("click",function(){
                $gaokao.show().siblings(".exam-cont").hide();
            });
            //期中期末
            $("#examtype2").on("click",function(){
                $qizhong.show().siblings(".exam-cont").hide();
            });
            //单元测试
            $("#examtype3").on("click",function(){
                $danyuan.show().siblings(".exam-cont").hide();
            });
            //课时训练
            $("#examtype4").on("click",function(){
                $keshi.show().siblings(".exam-cont").hide();
            })
        },

        // 删除选择题
        deleteLayer:function(){
            $("[data-event='delete']").on("click",function(){
                $(this).parent().siblings('.q-choice').html('')
            });
        },
    }
    $.baseJs.init();

    //整体高度固定
    $(".left-con").height($(window).height() - 22);
    $(".right-con").height($(".left-con").height());
    $(".left-con").height($(".right-con").height());

    // 分数显示
    $(document).on("click",".score-view label",function(e){
        e.preventDefault();
        var scoreview = $(this).find("input").val();
        $(this).find("input")[0].checked= true;
        if(scoreview == "1"){
            $(".score").show();
        }else if(scoreview == "0"){
            $(".score").hide();
        }
    });
})
