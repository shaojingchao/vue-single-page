define(function(){
    $.fillingJs = {
        innt: function(){
            var e = this;
            e.fillCon();    //填空题内容
        },
        // 填空题内容
        fillCon :function(num){
            var tpl = "";
            var count = 0;
            for (var i = 8; i < 13 ; i++) {
                tpl += '<div class="item-list">'+
                        '<span class="number">'+i+'.</span> '+
                        '<span class="line width1"></span>'+
                    '</div>';
            };
            $("#filling-qs .q-content .content-list").append(tpl)
        },
    }
    $.fillingJs.innt()
})
