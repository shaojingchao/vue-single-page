define(function(){
    $.frameJs ={
        init: function(){
            var e = this;
            e.commonframe();     //整体结构
            e.choiceframe();     //选择题
            e.filling();         //填空题
        },

        //整体结构
        commonframe: function(){
            $(".a4-page1 .con-height").append('<div class="part-wrap" id="choice-qs"></div>');
            $("#choice-qs").append('<div class="part-title center red hover"></div>');
        },
        //选择题
        choiceframe: function(){
            $("#choice-qs .part-title").append('<div class="part-menu">'+
                                        '<a href="javascript:;" class="btn" data-event="parttitle">'+
                                            '<i class="iconfont">&#xe601;</i>编辑'+
                                        '</a>'+
                                    '</div>');
            $("#choice-qs .part-title").append('<p class="partname1">第Ⅰ卷 (请用2B铅笔填涂)</p>');
            $("#choice-qs").append('<div class="part-box choice hover"></div>')
            $("#choice-qs .choice").append('<div class="part-menu">'+
                                        '<a href="javascript:;" class="btn" data-event="addchoice">'+
                                            '<i class="iconfont">&#xe602;</i>添加'+
                                        '</a>'+
                                        '<a href="javascript:;" class="btn" data-event="delete">'+
                                            '<i class="iconfont">&#xe600;</i>删除'+
                                       ' </a>'+
                                        '<a href="javascript:;" class="btn" data-event="changetype">'+
                                            '<i class="iconfont">&#xe60b;</i>切换版式'+
                                        '</a>'+
                                    '</div>')
            $(".choice").append('<div class="q-choice clearfix choice-a4"></div>')
            $(".part-wrap").append('<div class="height8"></div>')
        },
        // 填空题
        filling: function(){
            $(".a4-page1 .con-height").append('<div class="part-wrap" id="filling-qs"></div>')
            $("#filling-qs").append('<div class="part-title center red hover">'+
                                    '<div class="part-menu">'+
                                        '<a href="javascript:;" class="btn" data-event="parttitle">'+
                                            '<i class="iconfont">&#xe601;</i>编辑'+
                                        '</a>'+
                                    '</div>'+
                                    '<p class="partname2">第Ⅱ卷 (请用0.5毫米黑色签字笔作答) </p>'+
                                '</div>');
            $("#filling-qs").append('<div class="part-box fillin"></div>')
            $("#filling-qs").append('<div class="part-tips center red">请在各题目答题区域作答，超出黑色矩形边框限定区域答题无效</div>')
            $("#filling-qs .fillin").append('<div class="question"></div>')
            $("#filling-qs .fillin .question").append('<div class="q-title hover"></div>')
            $("#filling-qs .fillin .question").append('<div class="q-content hover"></div>')
            $("#filling-qs .fillin .question .q-title").append('<div class="part-menu">'+
                                                '<a href="javascript:;" class="btn" data-event="addfillin">'+
                                                    '<i class="iconfont">&#xe602;</i>添加'+
                                                '</a>'+
                                                '<a href="javascript:;" class="btn" data-event="edittitle">'+
                                                    '<i class="iconfont">&#xe601;</i>编辑'+
                                                '</a>'+
                                            '</div>');
            $("#filling-qs .fillin .question .q-title").append('<p>填空题<em class="score">(每小题20分)</em></p>')
            $("#filling-qs .fillin .question .q-content").append('<div class="part-menu">'+
                                                '<a href="javascript:;" class="btn" data-event="addfillin">'+
                                                    '<i class="iconfont">&#xe602;</i>添加'+
                                                '</a>'+
                                                '<a href="javascript:;" class="btn">'+
                                                    '<i class="iconfont">&#xe600;</i>删除'+
                                                '</a>'+
                                            '</div>');
            $("#filling-qs .fillin .question .q-content").append('<div class="content-list"></div>')
        }

    }
    $.frameJs.init();
})