define(function(){
    $.answerAlert = {
        init: function() {
            var e = this;
            e.alertTitle();          //试卷标题弹窗
            e.alertExamcont();       //准考证号弹窗
            e.alertAddchoice();      //添加选择题弹窗
            e.alertParttitle();      //第Ⅰ卷弹窗
            e.alertEdittitle();      //编辑标题弹窗
            e.alertAddfillin();      //添加填空题弹窗
            e.alertAddexplain();     //添加解答题弹窗
            e.alertAddexplainmore(); //添加多选题弹窗
            e.alertAddwriting();     //添加英语作文弹窗
            e.alertAddcomposition(); //添加语文作文弹窗
            e.saveAnswer();          //保存答题卡弹窗
            e.changetype();          //选题题切换版式
        },
        // 试卷标题弹窗
        alertTitle: function() {
            var html = __inline("/app/card/view/public/alert-title.tpl");
            $(document).on("click","[data-event='intell']", function() {
                var layer1 = layer.open({
                    title: "试卷标题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"],
                    yes: function(){
                        // 修改输入姓名
                        var alertTitle = $("#alert-paper-name input").val();
                        var textTitle = $("#paper-name");
                        textTitle.html(alertTitle);

                        // 修改主标题
                        var mainTitle = $("#maintitle");
                        var alertMaintitle = $("#alert-paper-title input").val();
                        mainTitle.html(alertMaintitle);

                        // 修改副标题
                        var subTitle = $("#subtitle");
                        var alertMaintitle = $("#alert-paper-subtitle input").val();
                        subTitle.html(alertMaintitle);

                        layer.close(layer1)
                    }
                });
                $.answerAlert.setPaper();
            });
        },
        examHeight:function(useh){
            // 准考证号区域高度
            var examlH = $("." + useh + " .intro-l").outerHeight();
            var examrH = $("." + useh + " .intro-r");
            examrH.outerHeight(examlH);
            var missH = $("." + useh + " .miss").outerHeight();
            var examrH = $("." + useh + " .intro-r").outerHeight();
            var barcodeH = $("." + useh + " .barcode");
            barcodeH.outerHeight(examrH - missH - 14);
        },

        // 准考证号弹窗
        alertExamcont: function() {
            var html = __inline("/app/card/view/public/alert-exam-cont.tpl");
            $("[data-event='examcont']").on("click", function() {
                layer2 = layer.open({
                    title: "编辑答题卡",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"],
                    yes :function(index,layero){
                        // 准考证号内容编辑
                        var cardt = $(".exam-cont .numwidth");
                        var caedt1 = $(".tab-card td em");
                        var edittext = $("input[name='examcard']").val();
                        cardt.html(edittext);
                        caedt1.html(edittext);
                        // 注意事项内容编辑
                        var noticet = $(".notice .text");
                        var editnotice = $("textarea[name='notice']").val();
                        noticet.html(editnotice);

                        $.answerAlert.examHeight("examtype-gk");
                        $.answerAlert.examHeight("examtype-dy");

                        layer.close(layer2)
                    }
                });
            });
        },
        // 第Ⅰ卷弹窗
        alertParttitle: function() {
            var html = __inline("/app/card/view/public/alert-part-title.tpl");
            $("[data-event='parttitle']").on("click", function() {
                layer3 = layer.open({
                    title: "添加试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"],
                    yes :function(index,layero){
                        // 第I卷内容修改
                        var nametext1 = $("input[name = 'partname1']").val();
                        var name1 = $(".partname1");
                        name1.html(nametext1);
                        // 第Ⅱ卷内容修改
                        var nametext2 = $("input[name = 'partname2']").val();
                        var name2 = $(".partname2");
                        name2.html(nametext2);

                        layer.close(layer3)
                    }
                });
            });
        },
        // 编辑标题弹窗
        alertEdittitle: function() {
            var html = __inline("/app/card/view/public/alert-edit-title.tpl");
            $("[data-event='edittitle']").on("click", function() {
                layer.open({
                    title: "编辑试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 添加选择题弹窗
        alertAddchoice: function() {
            var html = __inline("/app/card/view/public/alert-add-choice.tpl");
            $("[data-event='addchoice']").on("click", function() {
                layer4 =layer.open({
                    title: "添加选择题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"],
                    yes:function(){
                        $.choiceJs.choiceadd()
                        layer.close(layer4)
                    }
                });
                $.choiceJs.choicetype()
            });
        },
        // 添加填空题弹窗
        alertAddfillin: function() {
            var html = __inline("/app/card/view/public/alert-add-fillin.tpl");
            $("[data-event='addfillin']").on("click", function() {
                layer.open({
                    title: "添加填空题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 添加解答题弹窗
        alertAddexplain: function() {
            var html = __inline("/app/card/view/public/alert-add-explain.tpl");
            $("[data-event='addexplain']").on("click", function() {
                layer.open({
                    title: "添加试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 添加多选题弹窗
        alertAddexplainmore: function() {
            var html = __inline("/app/card/view/public/alert-add-explain-more.tpl");
            $("[data-event='addexplainmore']").on("click", function() {
                layer.open({
                    title: "添加试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 添加英语作文弹窗
        alertAddwriting: function() {
            var html = __inline("/app/card/view/public/alert-add-writing.tpl");
            $("[data-event='addwriting']").on("click", function() {
                layer.open({
                    title: "添加试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 添加语文作文弹窗
        alertAddcomposition: function() {
            var html = __inline("/app/card/view/public/alert-add-composition.tpl");
            $("[data-event='addcomposition']").on("click", function() {
                layer.open({
                    title: "添加试题",
                    content: html,
                    area:"620px",
                    btn:["确定","取消"]
                });
            });
        },
        // 保存答题卡弹窗
        saveAnswer: function() {
            $("[data-event='saveanswer']").on("click", function() {
                layer.confirm('是否生成答题卡', {icon: 3, title:'提示'}, function(index){
                    layer.close(index);
                });
            });
        },


        // 修改试卷标题弹窗
        setPaper: function(params) {
            $('#J_name-alert .view-title').on("click",function(){
                var $this = $(this);
                var tagname = $this.data("tag");
                var tagview = $this.data("view");
                $.answerAlert.viewTitle(tagname,tagview);
                if($this.data("view")==1){
                    $this.html('<i class="iconfont">&#xe608;</i>隐藏').parent().find("input").removeAttr("disabled");
                    $this.data({"view":0});
                }else{
                    $this.html('<i class="iconfont">&#xe609;</i>显示').parent().find("input").attr("disabled","disabled");
                    $this.data({"view":1});
                }
            });
        },
        // 设置显示隐藏
        viewTitle: function(a,b){
            var $tagname = $("[data-id='paper-head-"+a+"']");
            if(b==1){
                $tagname.show();

            }else{
                $tagname.hide();
            }
        },
        // 选题题切换版式
        changetype: function(){
            $("[data-event='changetype']").on("click",function(){
                $(".q-choice .choice-item").toggleClass("vertical-choice");
            })
        }
    }
    $.answerAlert.init();

})
