define(function(){
    var blockOpt = {
        trNum:10,  //添加题数
        trItem:4,  //选项个数
    };
    $.choiceJs = {
        // 选择题每行
        choicerow :function(num,optcount){
            var optrow = {
                choice:["A","B","C","D","E","F","G"],
                option:["√","×"]
            };

            var tpl = "";
            tpl += '<td><span class="item-number">'+ num +'</span></td>';
            // for (var i = 0; i < optcount; i++) {
            //     tpl += '<td><span class="item-option">[<b class="pad4">'+ optrow.choice[i] +'</b>]</span></td>';
            // };

            if($("#pand").is(':checked') == false){
                for (var i = 0; i < optcount; i++) {
                    tpl += '<td><span class="item-option">[<b class="pad4">'+ optrow.choice[i] +'</b>]</span></td>';
                };
            }else{
                for (var i = 0; i < 2; i++) {
                    tpl += '<td><span class="item-option">[<b class="pad4">'+ optrow.option[i] +'</b>]</span></td>';
                };
            }
            return tpl;
        },

        // 选择题每块
        choiceblock: function(opt){
            var arr = opt.trItem;
            var num = opt.trNum;
            var tpl = "";
            var item = Math.floor(num/5);
            var itemNum = num%5;
            for (var i = 0; i < item; i++) {
                tpl += '<table class="choice-item">'+
                    '<tbody>';
                        for (var j = 0; j < 5; j++) {
                            tpl += '<tr>'+ $.choiceJs.choicerow((j+i*5 + 1),arr) +'</tr>'
                        };
                tpl += '</tbody>'+
                '</table>';
            };
            if(itemNum > 0){
                tpl += '<table class="choice-item">'+
                    '<tbody>';
                        for (var k = 0; k < itemNum; k++) {
                            tpl += '<tr>'+ $.choiceJs.choicerow((k + i*5 +1),arr) +'</tr>'
                        };
                tpl += '</tbody>'+
                '</table>';
            }
            return tpl;
        },


        // 添加选择题
        choiceadd: function(){
            var old = $.choiceJs.choiceblock(blockOpt);
            var num = $('#choicenum').val();
            var shu = $('#optionnum').val();
            var newNum = (num-0) + (blockOpt.trNum -0);
            var configChoice = {
                trNum:newNum,
                trItem:shu
            };
            $.extend(blockOpt,configChoice);
            $(".q-choice").html('')
            $(".box-a4 .choice-a4").append($.choiceJs.choiceblock(configChoice));
        },

        //判断题
        choicetype: function(){
            $("#choice-type label").on('click',function(){
                var $option = ($(this).children().val() ==3);
                if($option){
                    $(this).parent().parent().next().hide()
                }else{
                    $(this).parent().parent().next().show()
                }
            })

        },

    }
    $(".box-a4 .choice-a4").html($.choiceJs.choiceblock(blockOpt));
})
