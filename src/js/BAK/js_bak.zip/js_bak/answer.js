define(function(){
    $.answerJs = {
        init: function() {
            var e = this;
            e.nameMod();       //头部名称信息
            e.simpleCard();    //准考证号模块
        },
        // 头部名称信息
        nameMod: function(){
            $(".a4-page1 .con-height").append('<div class="main-top hover" id="j_main-top" ></div>');
            $("#j_main-top").append('<div class="part-menu"><a href="javascript:;" class="btn" data-event="intell"><i class="iconfont">&#xe601;</i>编辑</a></div>');
            $("#j_main-top").append('<div class="name center" id="paper-name" data-id="paper-head-name">姓名_______________ 班级_______________ 考号_______________ 座位号___________</div>');
            $("#j_main-top").append('<div class="paper-title mintitle red center" id="maintitle" data-id="paper-head-title">XX县高级中学高二下学期月考</div>');
            $("#j_main-top").append('<div class="paper-title subtitle center" id="subtitle" data-id="paper-head-subtitle">语文答题卡</div>');
        },

        // 准考证号模块
        simpleCard: function(){
            // 准考证号简单版
            var simcard = '<div class="exam-number red">'+
                '<em class="numwidth">准考证号</em><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>'+
                '</div>';
            // 准考证号复杂版
            var tbody = [];
            tbody.push('<tr><td colspan="13" class="title"><em>准考证号</em></td></tr>');
            tbody.push('<tr class="pad8"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>');
            var row = '';
            row += '<td>';
            for (var i = 0; i < 10; i++) {
                row += '[<span class="pad4">' + (i) + '</span>]<br>'
            };
            row += '</td>';
            tbody.push("<tr>"+row+row+row+row+row+row+row+row+row+row+row+row+row+"</tr>")
            var comcard = '<div class="tab-card">'+
                '<table class="card">'+
                '<tbody>'+
                '</tbody>'+
                '</table>'+
                '</div>'

            // 注意事项
            var simnotice = '<div class="notice">'+
                '<h3>注意事项</h3>'+
                '<p class="text">1．答题前，请将姓名、班级、考场、座位号、准考证号填写清楚。<br>'+
                '2．客观题答题，必须使用2B铅笔填涂，修改时用橡皮擦干净。 <br>'+
                '3．主观题使用黑色签字笔书写。<br>'+
                '4．必须在题号所对应的答题区域内作答，超出答题区域书写无效。</p>'+
                '</div>';
            // 贴条形码区
            var simbarcode = '<div class="barcode center red">'+
                '<h3>贴条形码区</h3>'+
                '<p>（正面朝上，切勿贴出虚线方框）</p>'+
                '</div>';
            // 缺考标记
            var simmiss = '<div class="miss red">'+
                '<span class="miss-sign">缺考标记<em></em></span>'+
                '<span>考生禁填</span>'+
                '</div>';
            var layerbox = '<div class="intro-l left"></div><div class="intro-r right"></div>'

            $(".a4-page1 .con-height").append('<div class="exam-intro hover"></div>')
            $(".exam-intro").append('<div class="part-menu">'+
            '<a href="javascript:;" class="btn" data-event="examcont">'+
            '<i class="iconfont">&#xe601;</i>编辑'+
            '</a>'+
            '</div>')
            // 高考仿真
            $(".exam-intro").append('<div class="exam-cont layer1 examtype-gk"></div>')
            $(".examtype-gk").append(layerbox)
            $(".examtype-gk .intro-l").append(simcard,simnotice)
            $(".examtype-gk .intro-r").append(simbarcode,simmiss)
            // 期中期末
            $(".exam-intro").append('<div class="exam-cont layer1 examtype-qz" style="display:none"></div>')
            $(".examtype-qz").append(layerbox)
            $(".examtype-qz .intro-l").append(comcard)
            $(".examtype-qz tbody").append(tbody)
            $(".examtype-qz .intro-r").append(simbarcode,simnotice,simmiss)
            // 单元测试
            $(".exam-intro").append('<div class="exam-cont layer1 examtype-dy" style="display:none"></div>')
            $(".examtype-dy").append(layerbox)
            $(".examtype-dy .intro-l").append(simnotice)
            $(".examtype-dy .intro-r").append(simbarcode,simmiss)

            // 课时训练
            $(".exam-intro").append('<div class="exam-cont layer1 examtype-ks" style="display:none"></div>')
            $(".examtype-ks").append(layerbox);
            $(".examtype-ks .intro-l").append(simcard);
            $(".examtype-ks .intro-r").append(simmiss);
            $(".examtype-ks").append(simnotice);

        }
    }
    $.answerJs.init();

})