/**
 * @author 邵敬超
 * @date 2016/11/16
 */
define(function (require, exports, module) {
    Vue.component("paper-style-a3",{
        template:"#tpl-paper-style-a3",
        data:function(){
            return {}
        },
        methods:{}
    });
    // Vue.component("paper",{
    //    template:"#tpl-paper",
    //    data:function(){
    //        return {}
    //    },
    //    methods:{}
    //});Vue.component("paper",{
    //    template:"#tpl-paper",
    //    data:function(){
    //        return {}
    //    },
    //    methods:{}
    //});Vue.component("paper",{
    //    template:"#tpl-paper",
    //    data:function(){
    //        return {}
    //    },
    //    methods:{}
    //});Vue.component("paper",{
    //    template:"#tpl-paper",
    //    data:function(){
    //        return {}
    //    },
    //    methods:{}
    //});Vue.component("paper",{
    //    template:"#tpl-paper",
    //    data:function(){
    //        return {}
    //    },
    //    methods:{}
    //});


});