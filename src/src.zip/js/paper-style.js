/**
 * @author 邵敬超
 * @date 2016/11/16
 */
// 答题卡头部信息
Vue.component("main-top", {
    template: "#tpl-main-top",
    props: ["title"],
    methods: {
        showTitleAlert: function () {
            app.alert.state_alertTitle = true;
        }
    }
});
// 试题头信息
Vue.component('ques-title-info', {
    template: '<div class="q-title-inner" v-if="item.display==1"><p>{{item.title}}</p></div>',
    props: ["item", "score"]
})

//考试信息栏 A4
Vue.component("exam-info-a4", {
    template: "#tpl-exam-info-a4",
    props: ["care", "type", "data"],
    data: function () {
        return {}
    },
    methods: {
        showAlertExamInfo: function () {
            app.alert.state_alertExamInfo = true;
        }
    }
});

//考试信息栏 A3
Vue.component("exam-info-a3", {
    template: "#tpl-exam-info-a3",
    props: ["care", "type", "data"],
    methods: {
        showAlertExamInfo: function () {
            app.alert.state_alertExamInfo = true;
        }
    }
});
/*版式*/
Vue.component("paper-style", {
    template: "#tpl-paper-style",
    props: [
        "dataState",
        "layout",
        "data",
        "care",
        "title",
        "type",
        "examPart",
        "modal",
        "score"
    ],
    data: function () {
        return {
            hlineHeight: 48,
            quesTemp: {
                choice: ["A", "B", "C", "D", "E", "F", "G"],
                trueFalse: ["√", "x"]
            },
            autoOrderChoice: false,
            saveOldOrderID: []
        }
    },
    methods: {
        /*切换选择题版式*/
        changeTypeItemStyle: function (i, j) {
            var style = app.data.paper[i].list[j].style;
            if (style == 0) {
                app.data.paper[i].list[j].style = 1;
            } else {
                app.data.paper[i].list[j].style = 0;
            }
            app.dataState += 1;
        },
        /*编辑分卷标题*/
        showAlertEditPartTitle: function () {
            app.alert.state_alertPartInfo = true;
        },
        /*编辑标题*/
        showAlertEditQuesTitle: function (pid, tid) {
            Bus.$emit("showAlertEditQuesTitle", pid, tid);
            app.alert.state_alertEditQuesTitle = true
        },
        /*添加选择题*/
        showAlertXuanzeti: function (i, j) {
            Bus.$emit("showAlertXuanzeti", {part: i, block: j});
            app.alert.state_alertXuanzeti = true
        },
        /*添加填空题*/
        showAlertTiankongti: function (i,j) {
            Bus.$emit("showAlertTiankongti",{part: i, block: j});
            app.alert.state_alertTiankongti = true
        },
        /*添加解答题*/
        showAlertJiedati: function (i,j) {
            Bus.$emit("showAlertJiedati",{part: i, block: j});
            app.alert.state_alertJiedati = true
        },
        /*添加英语作文*/
        showAlertEditEnZuowen: function (pid, tid) {
            Bus.$emit("showAlertEditEnZuowen", pid, tid);
            app.alert.state_alertEnZuowen = true
        },
        /*添加语文作文*/
        showAlertEditCnZuowen: function (pid, tid) {
            Bus.$emit("showAlertEditCnZuowen", pid, tid);
            app.alert.state_alertCnZuowen = true
        },
        /*下移*/
        moveDownThisQues: function (pid,tid) {
            app.moveDown(pid,tid);
        },
        /*上移*/
        moveUpThisQues: function (pid,tid) {
            app.moveUp(pid,tid);
        },
        /*删除*/
        delThisQues: function (pid,tid,oid) {
            app.delQuesType(pid,tid,oid);
        }
    }
});

/*解答题*/
Vue.component("jd-kong-template",{
    template:"#tpl-jd-kong-template",
    props:["contentItem","partItemIndex", "typeItemIndex", "subOrderID","score","itemLength"],
    data:function(){
        return {
            hoverThis:0
        }
    },
    computed:{
        // 试题id
        cardQuesId:function(){
            var $this = this;
            return $this.contentItem.order+'.'+$this.contentItem.small;
        },
        // formatHline:function(num){
        //     var val = parseInt(num);
        //     if (val != num && val > 1){
        //         return parseInt(num);
        //     }else{
        //         return val;
        //     }
        //
        //
        // },

        kongItemLen:function () {
            var $this = this;
          return ((( 0 <$this.contentItem.hline && $this.contentItem.hline < 1 )
              ? 1 :
              $this.contentItem.hline ) * ( $this.contentItem.kong== 0 ? 1 : $this.contentItem.kong ));
        },
        isSmall:function(){
            return this.contentItem.small!=0
        },
        isNoImgClass:function () {
            var $this = this;
          return {'hang-1-3':$this.contentItem.hline==0.3,
              'hang-1-1':$this.contentItem.hline>=1,
              'hang-1-2':$this.contentItem.hline==0.5,
              'no-line':$this.contentItem.uline==0 || ($this.contentItem.desc && $this.contentItem.desc.length > 0)};
        },
        isImgClass:function () {
            var $this = this;
            if($this.contentItem.hline){
                return {'hang-1-3':$this.contentItem.hline==0.3, 'hang-1-1':$this.contentItem.hline>=1, 'hang-1-2':$this.contentItem.hline==0.5};
            }
        },
        isImg:function(){
            var $this = this;
            if(!$this.contentItem.img || ($this.contentItem.img && $this.contentItem.img.length===0)){
                return false;
            }else if($this.contentItem.img && $this.contentItem.img.length>0){
                return true;
            }
        },
        hangHasImgStyle:function(){
            return {'min-height':Math.max(this.kongItemLen * 48 , 150) + 'px'};
        },
        isQuesBlock:function(){
            var $this = this;
            if($this.contentItem.hline){
                return $this.contentItem.hline>=2;
            }
        },
        isContentLastQuesBlock:function () {
            return this.isQuesBlock === true && (this.itemLength - 1) === this.subOrderID
        },
        isShowQuesBlockLine:function(){
            var $this = this;
            if($this.contentItem.hline){
                return $this.contentItem.hline>=2 && $this.subOrderID !==0 && $this.contentItem.small <= 1;
            }
        },
        // 短文改错
        isENError:function () {
            return this.contentItem.kong == 0 && this.contentItem.hline == 0;
        }
    },
    methods:{

        /*删除*/
        delThisQues: function (pid,tid,oid) {
            app.delQuesType(pid,tid,oid);
        },

        /*下移*/
        moveDownThisQues: function (pid,tid,oid) {
            app.ItemMoveDown(pid,tid,oid);
        },

        /*上移*/
        moveUpThisQues: function (pid,tid,oid) {
            app.itemMoveUp(pid,tid,oid);
        },

        /*单题编辑 - 监听编辑试题弹框*/
        showAlertEditJiedati:function(pid,tid,oid){
            app.$forceUpdate();
            Bus.$emit("showAlertEditJiedati",{
                pid:pid,
                tid:tid,
                oid:oid
            });
            app.alert.state_alertEditJiedati = true;
        },

        /*单题操作-鼠标移入*/
        hoverThisQues:function(over){
            this.hoverThis = over;
        }
    }
});

// 选答题
Vue.component("xuandati-template", {
    template: "#tpl-xuandati-template",
    props: ["dataState", "partItem", "partItemIndex", "typeItemIndex", "score","typeItem"],
    data: function () {
        return {
            hlineHeight: 48
        }
    },
    computed:{

        // 重新定义选答题数据
        newType2:function () {
            var data = this.typeItem;
            var _this = this;
            var newType = $.parseJSON(JSON.stringify(data));//解除vue原数据绑定
            var newContent = {
                order: [],
                img: [],
                desc: [],
                small: 0,
                kong: 0,
                uline: 0,
                hline: 0,
                score: ''
            };
            var content = newType.content;
            for (var j = 0; j < content.length; j++) {
                var contentItem = content[j];
                newContent.order.push(contentItem.order);
                if(contentItem.img && contentItem.img.length>0){
                    newContent.img.push(contentItem.img);
                }
                newContent.hline = _this.getMaxNumber(j, content, 'hline');
                newContent.uline = _this.getMaxNumber(j, content, 'uline');
                newContent.score = _this.getMaxNumber(j, content, 'score');
            }
            newType.content = newContent;
            return newType;
        },

        //计算空总数量
        computedKong:function () {
            var newHline = this.newType2.content.hline;
            var newDo = this.newType2.do;
            return (newHline<=0 ? 1 : newHline) * newDo;
        },

        isHasImg:function () {
            return this.newType2.content.img != null && this.newType2.content.img.length>0
        }
    },
    methods: {

        /*下移*/
        moveDownThisQues: function (pid,tid) {
            app.moveDown(pid,tid);
        },
        /*上移*/
        moveUpThisQues: function (pid,tid) {
            app.moveUp(pid,tid);
        },
        /*删除*/
        delThisQues: function (pid,tid) {
            app.delQuesType(pid,tid);
        },
        // 获取数据中最大值
        getMaxNumber: function (i, obj, attr) {
            if (i == 0) {
                return obj[0][attr];
            }
            if (i > 0) {
                return Math.max(obj[i - 1][attr], obj[i][attr])
            }
        },
        showAlertEditQuesTitle: function (pid, tid) {
            Bus.$emit("showAlertEditQuesTitle", pid, tid);
            app.alert.state_alertEditQuesTitle = true
        }
    }
});

/*描述*/
Vue.component("ques-desc",
    {
        template:'<p class="J_ques-desc" v-if="viewIf" v-html="vHtml"></p>',
        props:["contentItem"],
        data:function () {
            return {
            }
        },
        computed:{
            viewIf:function(){
                return this.contentItem.desc && this.contentItem.desc.length>0
            },
            vHtml:function(){
                if(this.viewIf){
                    return this.contentItem.desc.replace(/\n/g,"<br\>")
                }
            }
        }
    });